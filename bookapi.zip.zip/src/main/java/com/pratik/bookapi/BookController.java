package com.pratik.bookapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookRepository repository;

    // GET /books → list all books
    @GetMapping
    public List<Book> getAllBooks() {
        return repository.findAll();
    }

    // POST /books → add a new book
    @PostMapping
    public Book addBook(@RequestBody Book book) {
        return repository.save(book);
    }

    // DELETE /books/{id} → delete by ID
    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        repository.deleteById(id);
    }

    // PUT /books/{id} → update book by ID
    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book updatedBook) {
        return repository.findById(id).map(book -> {
            book.setTitle(updatedBook.getTitle());
            book.setAuthor(updatedBook.getAuthor());
            book.setCategory(updatedBook.getCategory());
            book.setPrice(updatedBook.getPrice());
            return repository.save(book);
        }).orElseThrow(() -> new RuntimeException("Book not found with id " + id));
    }
}

